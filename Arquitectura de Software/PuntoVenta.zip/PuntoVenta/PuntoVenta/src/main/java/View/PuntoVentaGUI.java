

import Assembler.ProductoInteraccionEvent;
import Assembler.VentaErrorEvent;
import Assembler.VentaEvent;
import Assembler.VentaExitosaEvent;
import Controller.VentaController;
import Exception.CantitadCeroException;
import Exception.ProductoNoAsociadoException;
import Model.Producto;
import Model.Venta;
import Observer.VentaObserver;
import java.math.BigDecimal;

public class PuntoVentaGUI implements VentaObserver {

    private final VentaController controller;

    
    public PuntoVentaGUI() {
        Venta venta = new Venta(1);
        controller = new VentaController(venta);

        venta.getSuscriptores().add(this);
    }

    public void probarVenta() throws ProductoNoAsociadoException, CantitadCeroException {
        Producto p1 = new Producto(new BigDecimal("10.50"), "Coca Cola");
        Producto p2 = new Producto(new BigDecimal("25.75"), "Hamburguesa");

        controller.finalizarVenta(BigDecimal.valueOf(1500));
        controller.agregarProducto(p1);
        controller.agregarProducto(p1);
        controller.agregarProducto(p2);
        controller.agregarProducto(p1);
        controller.quitarProducto(p1);
        controller.finalizarVenta(BigDecimal.valueOf(1500));

    }

    public static void main(String[] args) {
        PuntoVentaGUI gui = new PuntoVentaGUI();
        try {
            gui.probarVenta();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void update(VentaEvent event) {
        System.out.println("Evento recibido: " + event.getTipoEvento());

        // Verificar si el evento es del tipo ProductoInteraccionEvent
        if (event instanceof ProductoInteraccionEvent pie) { // Java 16+ permite "pattern matching"
            System.out.println("Total de venta: " + pie.getTotalVenta());
            System.out.println("Productos en la venta:");
            pie.getProductos().forEach(p -> {
                System.out.println("- " + p.getProducto().getNombre() +
                        " x" + p.getCantidad() +
                        " = " + p.getTotal());
            });        
        }else if(event instanceof VentaErrorEvent ve) {
            System.out.println("Error: " + ve.getTipoEvento());
        }else if(event instanceof VentaExitosaEvent ve ) {
            System.out.println("La compra fue exitosa. Cambio del cliente: " + ve.getCambio());
        }
        else {
            System.out.println("Evento no reconocido, tipo: " + event.getClass().getSimpleName());
        }

        System.out.println("----------");
        }
}
